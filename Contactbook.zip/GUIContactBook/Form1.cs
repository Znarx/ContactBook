﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;



namespace GUIContactBook
{
    public partial class ContactBook : Form
    {
        private string fileName = "contacts.txt";

        public ContactBook()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string contactNumber = txtContactNumber.Text;

            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(contactNumber))
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(fileName, true))
                    {
                        writer.WriteLine(name + "," + contactNumber);
                    }
                    MessageBox.Show("Contact saved successfully.");

                    // Open the file in Notepad
                    OpenInNotepad(fileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving contact: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter both name and contact number.");
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            if (!string.IsNullOrEmpty(name))
            {
                try
                {
                    listBoxResults.Items.Clear();

                    using (StreamReader reader = new StreamReader(fileName))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split(',');
                            if (parts.Length == 2 && parts[0].Equals(name, StringComparison.OrdinalIgnoreCase))
                            {
                                // Add contact to ListBox
                                listBoxResults.Items.Add("Contact found: " + parts[0] + ", " + parts[1]);

                                // Display contact number in TextBox
                                txtContactNumber.Text = parts[1];

                                // Stop searching once contact is found
                                return;
                            }
                        }
                    }

                    // If contact not found, display message
                    listBoxResults.Items.Add("Contact not found.");
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("File not found. Please create contacts.txt in the application directory.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error searching contact: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter the name to search.");
            }
        }


        private void OpenInNotepad(string filePath)
        {
            try
            {
                // Open the file in Notepad
                Process.Start("notepad.exe", filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file in Notepad: " + ex.Message);
            }
        }
    }
}
